# Run the real OpenEBench leaderboard visualizer locally, against this benchmark's own data

This is NOT a clone of openebench.bsc.es -- there is no database, no submission API, no user
accounts. It runs the actual OPEN-SOURCE client-side chart component OpenEBench itself uses
(github.com/inab/OpenEBench_scientific_visualizer, built from source in this session) against
the PPI-PhysioClassification challenge's own aggregation dataset, via a small local mock of the
two GraphQL queries that component issues (`getDatasets`, `getMetrics`). It shows the exact same
scatter-plot leaderboard (with the square-quartile / diagonal / clustering classification modes
and CSV/PNG/PDF export) that the live OpenEBench site would render for this challenge, using
only the data this package produced -- no network access, no OpenEBench account needed.

**Why you have to run this yourself**: the sandbox this was built in cannot open a listening
network socket (verified -- even binding to 127.0.0.1 is blocked), so there is no way for me to
host a live, clickable URL for you from here. Everything needed is in this folder; starting it
takes one command on your own machine.

## Requirements

Python 3 (stdlib only -- no pip packages needed). The visualizer bundle (`build.js`) is already
built; you do not need Node/npm to run it, only to rebuild it from source if you want to change
the visualizer itself.

## Run it

```bash
cd oeb_local_visualizer
python3 serve_local_openebench_visualizer.py --port 8080
```

Then open **http://localhost:8080/** in a browser. You'll see the PPI-PhysioClassification
challenge's 14-participant leaderboard (AUC-ROC vs. Accuracy-at-threshold), fully interactive:
switch between square-quartile / diagonal / clustering classification views, toggle "optimal
view", and export the plot as JSON/PNG/PDF -- all features of the real OpenEBench component.

## What's inside

- `serve_local_openebench_visualizer.py` -- the local server. Serves the static visualizer page
  and mocks the two GraphQL queries (`getDatasets` for the aggregation dataset,
  `getMetrics` for metric display names) by reading directly from
  `oeb_ppi_benchmark/datasets/aggregation/*.json` and `oeb_ppi_benchmark/metadata/Metrics/*.json`.
- `visualizer_static/` -- `index.html` + the webpack-built `build/build.js`, compiled in this
  session from the unmodified `inab/OpenEBench_scientific_visualizer` source (`src/app.js` and
  friends) via `npm install && webpack-cli src/app.js --output=build/build.js -p`.
- `oeb_ppi_benchmark/` -- a minimal copy of just the two inputs the mock server reads: the
  challenge's aggregation Dataset instance and its Metrics definitions, taken directly from the
  full `oeb_ppi_benchmark.zip` package (same data, no changes).

## To point this at a different challenge

1. Replace `oeb_ppi_benchmark/datasets/aggregation/*.json` with your own aggregation Dataset
   instance (must conform to the OpenEBench 1.0.x Dataset schema, `type: "aggregation"`, with
   `datalink.inline_data.challenge_participants` and `.visualization.{type,x_axis,y_axis,
   optimization}`).
2. Replace the files in `oeb_ppi_benchmark/metadata/Metrics/` with your own Metrics records.
3. Update the `data-id` attribute in `visualizer_static/index.html` to match your aggregation
   dataset's `_id`.
4. Re-run the server -- no rebuild of `build.js` needed, since the visualizer code itself didn't
   change.

## Limits of this local setup (be aware before relying on it for anything beyond a demo)

- This serves exactly ONE challenge's precomputed aggregation result as static data -- it is
  not a live benchmarking pipeline, has no way to accept new submissions, and does not talk to
  the real openebench.bsc.es database at all.
- The mock GraphQL server is intentionally minimal: it does not implement the full GraphQL
  schema, pagination, or any query other than the two this specific visualizer component sends.
- `_metadata` on each metric is sent as an empty object (`{}`) since this package's Metrics
  records don't define OpenEBench's internal metric-metadata vocabulary (e.g. `level_2:metric_id`).


## BUGFIX (found and fixed after user report of a blank/white page)

**Symptom**: running the server and opening the page showed only the static `<h2>` title, no
chart -- exactly what happens when a synchronous JavaScript error aborts execution before any
rendering code runs.

**Root cause, confirmed by headless execution (Node + jsdom) of the actual built bundle**: the
original `index.html` used `data-id="3DBioinfo:2023-05-15_PPI-PhysioClassification_Aggregation"`.
The visualizer turns this into a DOM element id (colon -> underscore) and then calls
`document.querySelector('#' + that_id)` internally. A CSS id selector that starts with a digit
is invalid per the CSS spec unless escaped -- and `3DBioinfo...` starts with `3`. This throws
`SyntaxError: Invalid selector #3DBioinfo_...` synchronously, in every browser (not a jsdom
quirk), which aborts the whole visualization script before it ever fetches or renders data.

**Fix**: changed `data-id` to `"oeb-ppi-physio-classification"` (no leading digit). This is safe
because the local mock GraphQL server (`serve_local_openebench_visualizer.py`) does not filter
by the requested id -- it always returns this challenge's one aggregation dataset regardless of
what `data-id` is sent, so the value only needs to produce a valid DOM id, not match any real
identifier. Also removed a redundant, broken `<script>window.onload = function(){
load_scatter_visualization(); };</script>` line -- the bundled `build.js` already self-invokes
`load_scatter_visualization()` when it loads (see the bottom of `src/app.js`), so that extra
line was dead code that additionally threw its own `ReferenceError` (the function is not
exported to `window` by this build) once the first error was fixed.

**Verified the fix**, not just asserted it: reloaded the corrected `index.html` + `build.js` in
a headless Node/jsdom environment and confirmed (a) zero CSS `SyntaxError`s are thrown, and
(b) execution now correctly proceeds past the selector-dependent setup code (the classifier
dropdown list is successfully appended to the DOM) through to the actual data-fetch step -- the
only remaining event in that isolated test is a network failure, expected since no server was
running during the test itself; against your actual running `serve_local_openebench_visualizer.py`
this fetch will succeed and the chart will render.


## Page styling update: matching OpenEBench's visual identity

The chart itself was already OpenEBench's own CSS (bundled from `src/app.css` in the
visualizer's source). The page WRAPPING the chart (header, nav, colors, typography) is now
styled to match the real site, built from what could actually be verified rather than guessed:

- **Logo**: the real OpenEBench "oEB" logo, taken directly from
  `OpenEBench_scientific_visualizer/images/logo.png` (the same open-source repo providing the
  chart component) -- not redrawn or approximated.
- **Color**: `#0056b4`, measured directly from that logo's dominant blue (mean RGB of its
  non-white pixels), used for the header bar and link/accent color.
- **Typography**: `Roboto` + Material Icons, confirmed from `openebench.bsc.es`'s own page
  `<head>` (fetched directly: it loads `fonts.googleapis.com/css2?family=Roboto...` and
  `fonts.googleapis.com/icon?family=Material+Icons`), not assumed.
- **Layout**: a header bar + secondary nav + card-based content area, following common
  Material-Design conventions (the real site is a Nuxt.js/Vue single-page app using Material
  Icons, consistent with a Material-style design system) -- this part is a reasonable
  reconstruction, not a pixel-exact scrape, since the live site's actual page markup/CSS is
  generated client-side by its Nuxt JS bundles and could not be feasibly extracted statically.

**What this is NOT**: a copy of openebench.bsc.es's exact HTML/CSS/JS, its navigation structure,
or its real community/tool/challenge browsing pages. It is a locally-styled wrapper, using the
platform's real logo/colors/fonts, around the real chart component rendering your own data --
clearly labelled as a local, offline preview in its own banner text, not a live submission.


## Rebranding + page organization update (reference: real CAID benchmarking page)

**Logo swapped**: OpenEBench's logo replaced with the real BioFolD logo (`biofold.org/pages/img/logo.png`,
fetched directly -- used at its native 75px width, same as on biofold.org itself). Header title
now reads "BioFolD" instead of "OpenEBench".

**Page organization verified against a real, live OpenEBench benchmarking page**, not guessed:
queried the public OpenEBench Scientific GraphQL API (`https://openebench.bsc.es/api/scientific/graphql`)
directly for the CAID benchmark referenced by the user
(https://openebench.bsc.es/benchmarking/OEBC011?event=OEBE0110000000) and confirmed its real
structure:
- Community OEBC011 = "Critical Assessment of protein Intrinsic Disorder prediction" (CAID)
- BenchmarkingEvent OEBE0110000000 = "CAID1"
- 3 Challenges under that event (disprot-binding-all, disprot-disorder-pdb-atleast,
  disprot-disorder), each with multiple per-metric "Summary dataset" aggregations
  (participant -> single metric_value, e.g. AUCpreD-np: 0.751)

This confirmed the real page's information hierarchy is **Community -> Benchmarking Event ->
Challenges -> per-challenge leaderboard**, which the local page now follows, populated directly
from this package's own metadata (not hardcoded placeholder text): a Community card (name,
acronym, description, keywords -- straight from `metadata/Community.json`), a Benchmarking Event
card (name, dates, reference url -- from `metadata/BenchmarkingEvent.json`), a Challenges card
listing this benchmark's one challenge (from `metadata/Challenges/*.json`), and the leaderboard
chart section (unchanged from before).

Note: CAID's real challenges use a single-metric bar/ranking display (one `metric_value` per
participant) rather than the x/y scatter this PPI benchmark's aggregation dataset already uses
(AUC-ROC vs. Accuracy) -- the user's instruction was about page ORGANIZATION, not chart type, so
the existing, already-verified 2D-scatter chart was kept as-is.

Re-verified with the same headless Node/jsdom check used for the earlier bugfix: zero syntax
errors, BioFolD logo renders, Community/Challenge text populated correctly, chart div and
dropdown still initialize correctly.


## Sidebar navigation + title update

Added a left sidebar with three sections (Results / Datasets / Tools), each a simple in-page
anchor link, populated from the package's own data rather than placeholder text:
- **Results** -> the existing leaderboard chart card.
- **Datasets** -> a table of every OpenEBench Dataset type present in this package and how many
  instances exist of each (pulled by counting files under `datasets/*/`, e.g. 14 participant
  datasets, 28 assessment datasets, 1 aggregation dataset).
- **Tools** -> a table of all 14 participant tools with their display name and internal
  OpenEBench-style id, pulled directly from `metadata/Tools/*.json` (the 3 internal metric/
  aggregation-computation tools are excluded from this list since they are not benchmark
  participants).

Page title (both the `<title>` tag and the header banner text) changed to "ELIXIR 3DBioinfo
Community PPI Benchmark Experiment" as requested.

Re-verified with the same headless Node/jsdom check: zero syntax errors, correct `document.title`,
all three sidebar links present with the right anchor hrefs, all three target sections render
with the expected row counts (14 tools, 6 dataset types), and the leaderboard chart still
initializes correctly.


## BioFolD branding removed; CV-validated submission upload added

Per follow-up feedback, the page's BioFolD branding (logo, "BioFolD" header subtitle, footer
BioFolD/biofold.org credit) has been removed entirely -- the header now reads only "ELIXIR
3DBioinfo Community PPI Benchmark Experiment / local challenge preview", with no logo image.
The footer disclaimer sentence about CAID-page-referenced organization / non-affiliation with a
live openebench.bsc.es submission has also been removed from the footer (a shorter, purely
informational notice about this being an offline local preview remains near the top of the page,
since that is materially different text providing an important factual disclosure).

A new **Submit new predictions** section (linked from the sidebar) lets a user upload a
predictions CSV (`entry_id` + `score`/`raw_score`/`raw_score_oriented`) and see it evaluated
against the existing 14 participants under a declared, leakage-safe cross-validation splitting
procedure (selectable among the package's 4 CV strategies, with a link to their full
description). For every participant shown -- the uploaded one and the 14 existing ones alike --
the reported AUROC/AUCPR/Balanced-Accuracy/F1/MCC are **held-out, cross-validated** metrics: for
each fold, the decision threshold is learned only from the other folds (Youden's J), never from
the held-out fold itself, and no participant's published threshold is used in this comparison
(this is deliberately different from, and stricter than, the resubstitution-against-the-manuscript
comparison in the Results section). Every leaderboard row links to that participant's own
submission file (`predictions.csv`), and the results panel links to the exact reference data
(`gold_standard_labels.csv`) and fold-assignment file used for the evaluation. The Tools and
Datasets sections also now link directly to each participant's submission file and to the
package's reference/evaluation data files.

Server-side additions (`serve_local_openebench_visualizer.py`): a dependency-free multipart/
form-data parser (the stdlib `cgi` module this used to rely on was removed in Python 3.13, so a
hand-rolled parser is used instead for forward compatibility), a `POST /api/evaluate_submission`
route running the same `cv_evaluate.py` engine used to precompute the baseline leaderboards
(`qc_analysis/cv_leaderboard/strategy{1,2,2b,3}.json`), a `GET /api/strategies` route for the
dropdown, and a `GET /package/<path>` route serving read-only downloads of any file under the
package directory (with path-traversal protection), used for all the submission-file/
reference-data links. All of this was verified by directly exercising the handler's `do_GET`/
`do_POST` methods against mocked request/response objects (this sandbox cannot bind a real
listening socket, confirmed earlier) and by a headless Node/jsdom render of the page (zero syntax
errors, all new DOM elements present, chart still initializes).


## Figure update on submission (new)

The Submit section now includes its own scatter chart (CV AUROC vs. CV Balanced Accuracy, both
cross-validated under the chosen strategy) that redraws every time a prediction file is
evaluated: all 14 baseline participants plus the newly uploaded submission (highlighted in
orange, labeled by name, larger marker) are plotted together, with the Pareto frontier (points
not beaten on both axes by any other point) drawn as a dashed line when more than one point is
non-dominated. This is a separate, purpose-built SVG chart (not the real OpenEBench visualizer
component used for the static Results-section leaderboard above), because the two charts show
different, non-interchangeable things: the Results-section chart is the resubstitution AUC-ROC
vs. Accuracy-at-threshold comparison against the manuscript's published thresholds, while this
one is the held-out, cross-validated comparison described in the "Submit new predictions"
section -- plotting a newly uploaded, un-published-threshold submission onto the former chart
would silently mix two different evaluation protocols.

Verified by extracting and directly invoking the chart-drawing function in a headless Node/jsdom
environment against real evaluate_submission() output: correct point count, correct highlighting
and tooltip text for the new submission, and correct Pareto-frontier line drawing (tested
separately against a synthetic leaderboard with a non-trivial multi-point frontier, since the
real benchmark data happens to have a single dominant participant, Random Forest consensus, on
this metric pair).


## Update (per feedback): no more duplicate table/figure for submissions

Per follow-up feedback, the separate "Submit results" table and scatter chart introduced in the
previous iteration have been removed. A submitted prediction's results are now appended directly
to the EXISTING "Full metrics table" and drawn as an extra point directly on the EXISTING
AUC-ROC-vs-Accuracy chart in the Results section -- there is exactly one metrics table and one
chart on the page, both before and after a submission.

- **Table**: the new row is inserted into `#full-metrics-tbody` (highlighted, with a 7th
  "Evaluation" column reading e.g. "CV (Strategy 3 -- combined union ...)"), replacing any row
  from a previous submission rather than accumulating duplicates on resubmission. The 14 baseline
  rows also gained this "Evaluation" column (reading "published threshold (resubstitution)" or,
  for Voronota, "data-driven optimal threshold (resubstitution)") so the methodology difference
  between the CV-evaluated submission and the resubstitution-evaluated baseline rows is explicit,
  not hidden by sharing one table.
- **Chart**: the real OpenEBench visualizer library (`app.js`) exports `load_scatter_visualization`
  as a `window` global (`libraryTarget: 'this'` in its webpack config) and builds all of its DOM
  output (dropdown, buttons, SVG, table) as descendants of the chart's own `<div>` -- confirmed by
  reading the library's source. This means the existing chart can be safely refreshed in place:
  clear that div's `innerHTML` and call `window.load_scatter_visualization()` again. The server
  now keeps the most recent submission's point in memory (never written to disk, replaced -- not
  accumulated -- on each new submission, cleared on restart) and merges it into the mocked
  GraphQL response that chart fetches, so the redraw picks it up automatically. The chart's
  subtitle gains a small "(updated with your latest submission)" note once this has happened.

Verified end-to-end in a headless Node/jsdom session by defining a mock `window.fetch`,
dispatching a real `submit` event on the actual form, and checking: the table goes from 14 to 15
rows (not 16 on a second submission), the chart div is cleared and rebuilt with no duplicate
dropdown/button elements, and the live-update note appears. Also verified at the Python level
that the server's in-memory point is replaced (not appended) across repeated submissions and that
`build_dataset_response()` correctly merges it into the chart's data for both the standalone
bundle and the package-embedded copy.


## Fixes: table re-sorts, new submission's chart point is black

Per follow-up feedback, two corrections to the in-place update behavior:

- **Table sorting**: the new submission's row was previously only appended at the end of the
  "Full metrics table". Every row (the 14 baseline participants and the submitted one) now carries
  a `data-auroc` attribute, and `updateMetricsTable()` re-sorts all rows by AUROC descending after
  inserting the new one, so it lands at its correct rank rather than always last. Verified in a
  headless Node/jsdom session by dispatching a real form submission and checking the resulting
  `data-auroc` values are monotonically decreasing top to bottom.
- **New submission's chart point in black**: the real OpenEBench visualizer assigns each point's
  color from an automatic ordinal D3 palette keyed by tool name (confirmed from
  `chart_coordinates.js`), with no per-point override in its data model. The point for a newly
  uploaded submission is now forced to black: the server returns the exact (possibly truncated)
  label the chart library will use for that point as `chart_tool_id`, and the page computes that
  point's DOM id the same way the library itself does (`"<chartDivId>___" + name.replace(/[.
  ()\/-]/g, "_")`, read directly from the library's own source) and overrides its `fill`/`stroke`
  to black once it appears -- via a `MutationObserver` on the chart container (since the chart
  redraws asynchronously), with an immediate check in case it is already present and a timeout
  fallback. This was verified directly against a DOM shaped exactly like the real chart's output
  (confirmed from source rather than guessed): both the "point already present" and "point appears
  later asynchronously" code paths correctly turn the matching point black, leaving others
  untouched.

Note: the real chart's own GraphQL data-fetching library (`apollo-fetch`, which uses
`XMLHttpRequest` internally rather than `window.fetch`) could not be driven end-to-end inside
headless jsdom for this round of testing, so the black-highlight logic was verified in isolation
against the library's real DOM output shape instead of a full live render -- the sort fix was
verified fully end-to-end since it does not depend on that library's network layer.


## Fix: new submission's chart point still showed its auto-assigned color (orange), not black

Root cause: the previous fix identified the point to recolor by reconstructing its DOM id from a
hand-replicated copy of the chart library's own sanitization regex, and gave up after a single
MutationObserver pass with a 6-second timeout. In practice the chart's data fetch is two
*sequential* network round trips (getDatasets, then getMetrics) before the dots are drawn, and any
mismatch or slow round trip meant the override silently never applied, leaving the point at
whatever color the library's automatic ordinal palette happened to assign it (orange, in the
reported case).

Fix: `highlightNewSubmissionDot()` now identifies the correct point by the **datum D3 itself bound
to each dot** (its `toolname` field, read via `window.d3.select(path).datum()` -- the library
exposes its own `d3` instance as `window.d3`), instead of reconstructing an id string. This is
exact by construction (no regex to keep in sync with the library's own implementation) and was
verified directly against the bundled library's real `d3` instance performing a real `.data().
enter().append("path")` join (the same pattern `chart_coordinates.js` uses), confirming the
correctly-identified point turns black while an unrelated point keeps its original color. The
retry window was also extended from a single 6s attempt to up to ~30s (polling every 500ms plus an
immediate MutationObserver reaction), to comfortably cover the chart's two-request fetch chain.


## Root cause found and fixed: wrong CSS class in the point selector

The previous fix still failed in practice because it selected candidate points with
`chartDiv.querySelectorAll("path.benchmark_path")`. Re-reading `chart_coordinates.js` closely
showed that each dot's class is set to `"benchmark_path"` only transiently: the very same chained
D3 call later does `.attr("class", "line")`, overwriting it before rendering finishes. By the time
`highlightNewSubmissionDot()` ever ran, there were zero elements with class `"benchmark_path"` left
in the DOM, so the search silently found nothing and the dot kept its original ordinal-palette
color (orange). Fixed by selecting `svg path` broadly and relying entirely on the bound datum's
`toolname` check (already in place) to pick the right one -- this is correct regardless of which
class name the library currently uses.

Also made the `MutationObserver` persistent (it no longer disconnects after the first successful
highlight): the "optimal view" toggle button and the classification-method dropdown both call
`createChart()` again from scratch, replacing every dot element, which would otherwise silently
drop the highlight on the next user interaction with the chart.

Verified by replicating the library's exact real sequence (`class="benchmark_path"` then
overwritten to `class="line"`, exactly as `chart_coordinates.js` does it) against the actual
bundled `d3` instance, for both an initial render and a simulated full chart rebuild: the new
submission's point is correctly found and colored black in both cases, while an unrelated point's
color is left untouched.


## Fixes: legend swatch still orange, chart overflowing the Results card

- **Legend color**: the chart's legend (`legend.js`) draws a SEPARATE set of `<path>` symbol
  elements from the main scatter dots, bound to a different datum shape -- a legend swatch's
  datum is the plain toolname STRING itself (`.data(color_domain)`, an array of names), not the
  `{toolname, x, y, ...}` object bound to a main dot. `findAndApply()` now checks both shapes
  (`typeof datum === "object" ? datum.toolname : datum`) and recolors every matching `<path>`
  across BOTH structures in one pass, rather than stopping at the first match -- so the main dot
  and the legend swatch are both forced to black. Verified against a DOM replicating both the
  real main-dot data-join and the real legend data-join exactly as `chart_coordinates.js` and
  `legend.js` construct them.
- **Chart sizing**: the library computes the chart's pixel width/height from the full browser
  window (`$(window).width() * 0.6818`, in `scatter_plot.js`), with no awareness of the narrower
  content column this page actually gives it (sidebar + card padding), which could make it wider
  than the Results-section card. Since the library already renders the SVG with a `viewBox` and
  `preserveAspectRatio` (confirmed from source), it is safe to let CSS take over the display size:
  `#oeb-chart-wrapper svg.benchmarkingSVG { max-width: 100%; height: auto; }` makes it scale down
  responsively to fit the card instead of overflowing, with `overflow-x: auto` on the wrapper as a
  fallback for the appended results table/legend row if they are ever still wider than the card.


## New: per-metric Quartile ranking table (5 columns, not 1)

Added a "Quartile ranking" table directly below the Full metrics table, with one column per
performance measure (AUROC, AUCPR, Balanced Accuracy, F1, MCC) instead of the single combined
quartile column the real OpenEBench visualizer's native `toTable` feature produces (that feature
is hard-wired to a single 2D x/y split -- the quadrant a point falls into on exactly the chart's
two axes -- which is why only one column existed before; it cannot be extended to 5 independent
metrics without reimplementing it). Each cell is Q1 (top 25%) through Q4 (bottom 25%), computed
independently per metric over the currently displayed population (higher is better for all 5),
color-coded (green Q1 -> red Q4) for quick scanning, matching the structure referenced on the
real CAID benchmarking page (openebench.bsc.es/benchmarking/OEBC011?event=OEBE0110000000), whose
underlying data model likewise reports one summary per metric rather than a single joint
classification.

Quartile boundaries are recomputed from scratch every time the Full metrics table changes (i.e.
whenever a new prediction is submitted), since they depend on the whole current population, not
fixed at page load -- `recomputeQuartileTable()` is called from the same `updateMetricsTable()`
that already handles sorting, using the identical `data-auroc`/`data-aucpr`/`data-balancedaccuracy`/
`data-f1`/`data-mcc` attributes already present on every row (baseline and submitted alike) for
sorting, so no second data source needs to be kept in sync.

Verified end-to-end in a headless Node/jsdom session: 14 initial rows with correctly shaped
5-metric rows, and after a real form submission the table grows to 15 rows with the new,
highlighted row's quartiles correctly recomputed against the now-15-participant population.


## Fixes: removed native 2-column table, Quartile ranking now follows the chart's Classification Method

Per follow-up feedback:

- **Removed the native per-chart classification table** (the real visualizer's `toTable="true"`
  feature): it only ever has one column (whichever quadrant a point falls into on the chart's two
  axes), is not something other real OpenEBench benchmarking pages show (confirmed from the live
  CAID page's own data model, which reports one summary per metric rather than a joint 2D
  classification), and duplicated purpose with the custom Quartile ranking table. The chart div's
  `toTable="true"` attribute was removed.
- **Quartile ranking now follows the chart's own "Classification Method" dropdown** (Square
  quartiles / Diagonal quartiles / K-Means clustering / No classification), exactly like the
  native per-chart table used to, but applied independently to each of the 5 performance measures
  instead of only the chart's x/y pair:
  - *Square* and *Diagonal* quartiles are mathematically identical for a single metric (confirmed
    by reading `diagonals.js`: its "distance-to-corner" score is `x_norm + y_norm`, which for a
    single axis reduces exactly to that metric's own normalized value -- so the quartile split is
    the same equal-population percentile split `squares.js` already computes). This is stated
    explicitly in the table's subtitle rather than silently treating them as different.
  - *K-Means clustering* runs genuine 1-D k-means (k=4, several random restarts to avoid bad local
    minima) independently per metric, with clusters ranked by mean (Q1 = best-performing cluster)
    -- a real, data-driven natural-breaks grouping rather than equal-population percentiles, and
    reliably produces different groupings than Square/Diagonal in practice.
  - *No classification* (the dropdown's own default) hides the table with an explanatory note,
    matching the native table's own behavior of going empty in that mode.
  - Because the chart's `<select>` element is recreated from scratch every time the chart
    re-renders, the method-change listener is attached via event delegation on a stable ancestor
    (`#oeb-chart-wrapper`) rather than directly on the dropdown, so it survives any number of chart
    rebuilds.
  - A new submission recomputes the table using whichever classification method is currently
    selected (it does not silently reset to a default), consistent with everything else being
    updated in place rather than duplicated.

Verified end-to-end in a headless Node/jsdom session: initial state is empty with the note shown
(matching the dropdown's "No classification" default); dispatching simulated dropdown-change
events for each method correctly repopulates the table, with K-Means producing visibly different
groupings from Square/Diagonal for the same data; switching back to "No classification" empties it
again; and submitting a new prediction while K-Means is selected preserves that method for the
resulting 15-row table.


## New: "Group" column added as the first column in all tables

Added a Group column (research group that contributed each scoring function, per the manuscript's
13 participating groups) as the FIRST column in the Full metrics table, the Quartile ranking
table, and the Tools table:

- Bonvin, Schueler-Furman, Venclovas, Zou, Guerois, Fernandez-Recio, SWISS-MODEL,
  Casadio (Bologna), Kihara, Correia, Oliva, MOBI, Wolfson -- the 13 named contributing groups.
- RF_Consensus_top221 is labeled "Consensus (cross-group RF)" since it is a derived Random Forest
  consensus of all other groups' scores, not an individually contributed group method.
- A newly uploaded submission is labeled "User submission" in this column, since it does not
  belong to one of the manuscript's named groups.

The Quartile ranking table's rows are built dynamically in JS from the Full metrics table's rows
(not a second data source), so its participant-name lookup (previously the first `<td>`) was
updated to read the second cell now that Group occupies the first position, and a `data-group`
attribute was added to every row (baseline and submitted) so the Quartile table can render its own
Group column without re-deriving it.

Verified end-to-end in a headless Node/jsdom session: all three tables' headers read "Group" first
followed by their original columns; dispatching a dropdown classification-method change correctly
renders the Quartile table with Group names intact; and submitting a new prediction correctly adds
a "User submission" row (with the right data attributes) to both the Full metrics and Quartile
tables without breaking the Group column in either.


## New: Group Name field, independent sidebar sections, link to updated results

Three changes per follow-up feedback:

- **Group Name field added to the Submit form**, positioned before "Submission name" as requested.
  The server now accepts a `group_name` field alongside `participant_name` and `strategy`; the
  uploaded row's Group column (added in the previous round) now shows whatever the user entered
  there instead of the fixed placeholder "User submission" (which remains the fallback only when
  left blank).
- **Sidebar sections are now shown independently** (Results / Datasets / Tools / Submit): instead
  of all four being stacked on one continuously scrolling page with the sidebar merely jumping
  between anchors, only one is visible at a time -- clicking a sidebar link now hides the others
  and highlights the active one, with the URL hash kept in sync (`#results-section` etc.) so
  direct links and back/forward navigation still work. The three informational cards above them
  (Community, Benchmarking Event, Challenges) remain always visible, since they are not
  individually linked from the sidebar.
- **The submission form now links to an updated results page**: after a successful evaluation, a
  "View updated results" button appears (in addition to the existing in-place table/chart update)
  that switches directly to the Results tab -- meaningful now that Results is its own independent
  section rather than always visible below the Submit form.

Verified end-to-end in a headless Node/jsdom session: initial load shows only Results active;
clicking each sidebar link shows exactly that section and hides the others, with the correct
nav-link highlighted; the Group Name field precedes Submission name in the form; a full submission
with a group name correctly populates the Group column with that value (confirmed directly via
`evaluate_submission()` too, including the blank-input fallback to "User submission"); and clicking
"View updated results" from the Submit tab correctly switches to the Results tab.


## Fix: Results page now shows automatically after submitting, no extra click needed

Per follow-up feedback, a successful submission now switches to the Results tab automatically
(`showSection("results-section")` is called right after the table/chart are updated), instead of
requiring the user to click the "Results" sidebar link or the "View updated results" button
themselves afterward. The button remains visible as a secondary confirmation/manual fallback, but
is no longer required.

Verified end-to-end in a headless Node/jsdom session: starting from the Submit tab, dispatching a
real form submission, and confirming that -- with no further simulated clicks -- the Results tab
becomes active, the Submit tab becomes hidden, the URL hash updates to `#results-section`, and the
Results sidebar link is marked active.

## Fix: chart kept showing a submission after a browser refresh, even though the table had reset

Root cause: the Full metrics table and Quartile table are static, server-rendered HTML -- a
browser refresh naturally resets them to their 14-participant baseline since nothing re-fetches
them. The chart, however, is rebuilt from a live GraphQL request every time the page loads
(including on a refresh), and the server's in-memory `LIVE_SUBMISSION_POINT` had no notion of
"this request is a fresh page load, not a continuation of the same session" -- so it kept merging
in a stale point from a submission the rest of the freshly-loaded page no longer showed at all.

Fixed by clearing `LIVE_SUBMISSION_POINT` whenever the server serves the main page (`GET /` or
`GET /index.html`), so a full page (re)load always starts consistent -- chart and tables both back
to the 14-participant baseline -- while a submission still updates both live within the same page
session exactly as before, via the submit form's own fetch calls (which do not hit `/` or
`/index.html`).

Verified directly by calling the server's actual request-handling code: submitting sets the
in-memory point (chart data goes to 15 participants); simulating `GET /` (and separately
`GET /index.html`) resets it (chart data back to 14); and other routes used during a normal page
session (`/api/strategies`, `/package/...` downloads) were confirmed to leave it untouched, so
no incidental fix in normal use. Verified against both the standalone bundle and the
package-embedded copy.

## Architecture fix: no more duplicated package data when embedded in oeb_ppi_benchmark.zip

Per a design-review question, this duplication was removed: this folder used to bundle a full
SECOND copy of the package's own data (a ~1MB subset -- datasets/, metadata/, workflow/
cv_evaluate.py) nested at `local_visualizer/oeb_ppi_benchmark/`. This was real duplication, not
just clutter: it had already caused one real bug earlier in this project (a metrics update applied
to the main package tree was not mirrored into this nested copy, so the embedded visualizer
briefly showed stale data).

Fixed by making the server locate its data automatically: `resolve_default_package_dir()` detects
that the real, complete package data exists one directory up (`../metadata`, `../datasets`) and
uses those canonical files directly -- including the canonical `workflow/cv_evaluate.py` rather
than a duplicate copy. The nested `oeb_ppi_benchmark/` subfolder that used to live here was
deleted; only `serve_local_openebench_visualizer.py`, `visualizer_static/`, and this README remain.

Run it exactly as before, from within the full package: `cd oeb_ppi_benchmark && python3
serve_local_openebench_visualizer.py` (no `--package` argument needed -- the script lives directly in the package root alongside `metadata/`/`datasets/` and resolves to its own directory automatically).
