#!/usr/bin/env python3
"""
Local webserver running the REAL OpenEBench scientific visualizer
(github.com/inab/OpenEBench_scientific_visualizer, built from src/) against the
actual Dataset-model JSON produced for the PPI-PhysioClassification challenge in
oeb_ppi_benchmark/. This is NOT a clone of openebench.bsc.es (no database, no
submission API, no auth) -- it serves ONLY the client-side leaderboard
visualization component against this one challenge's static data, via a minimal
mock of the two GraphQL queries (getDatasets, getMetrics) that component issues.

Usage:
    python3 serve_local_openebench_visualizer.py [--port 8080] [--package PATH]
Then open http://localhost:8080/
"""
import argparse, json, glob, os, sys, re
from http.server import BaseHTTPRequestHandler, HTTPServer


def resolve_default_package_dir():
    """This server script ships at one of three locations, checked in order:
      1. Directly inside the full oeb_ppi_benchmark package root (this script sits right next to
         metadata/, datasets/, workflow/, etc. as plain siblings) -- the single unified package
         layout: the web page's launch files live at the top, with every submission file directly
         below/alongside it, nothing nested.
      2. The standalone oeb_local_visualizer.zip bundle, where it sits next to its own
         self-contained oeb_ppi_benchmark/ subset copy of the data it needs.
      3. (Legacy) embedded one directory below the full package root (an earlier packaging
         arrangement, e.g. oeb_ppi_benchmark/local_visualizer/serve_...py) -- kept only as a
         fallback for robustness, not produced by this project anymore.
    Picks whichever actually exists relative to this script, so --package does not need to be
    passed explicitly in any case, and is also used to locate cv_evaluate.py below. Avoiding a
    bundled copy wherever a real sibling/ancestor package already exists prevents the two ever
    drifting out of sync (a real bug this project hit once already: a metrics update was applied
    to the main package tree but not mirrored into a nested duplicate)."""
    here = os.path.dirname(os.path.abspath(__file__))

    if os.path.isdir(os.path.join(here, "metadata")) and os.path.isdir(os.path.join(here, "datasets")):
        return here

    standalone_copy = os.path.join(here, "oeb_ppi_benchmark")
    if os.path.isdir(os.path.join(standalone_copy, "metadata")) and os.path.isdir(os.path.join(standalone_copy, "datasets")):
        return standalone_copy

    parent = os.path.dirname(here)
    if os.path.isdir(os.path.join(parent, "metadata")) and os.path.isdir(os.path.join(parent, "datasets")):
        return parent

    return os.path.join(here, "oeb_ppi_benchmark")  # last-resort fallback; 404s informatively if missing


sys.path.insert(0, os.path.join(resolve_default_package_dir(), "workflow"))
import cv_evaluate  # dependency-free CV engine shared with the CLI scripts

STRATEGY_FILES = {
    "strategy1": "cv_fold_assignment.csv",
    "strategy2": "cv_fold_strategy2_mmseqs2_strict.csv",
    "strategy2b": "cv_fold_strategy2b_blastclust_reference.csv",
    "strategy3": "cv_fold_strategy3_combined_union.csv",
}


def parse_multipart(body_bytes, content_type):
    """Hand-rolled, dependency-free multipart/form-data parser (the stdlib
    `cgi` module that used to do this was removed in Python 3.13, so this
    avoids depending on it). Returns a dict of field name ->
    {"value": str} for plain fields, or {"filename": str, "content": bytes}
    for file fields."""
    m = re.search(r'boundary="?([^";]+)"?', content_type)
    if not m:
        raise ValueError("no multipart boundary found in Content-Type header")
    boundary = ("--" + m.group(1)).encode()
    parts = body_bytes.split(boundary)
    out = {}
    for part in parts:
        part = part.strip(b"\r\n")
        if not part or part == b"--":
            continue
        if b"\r\n\r\n" not in part:
            continue
        header_blob, content = part.split(b"\r\n\r\n", 1)
        content = content.rstrip(b"\r\n")
        headers = header_blob.decode(errors="replace")
        name_m = re.search(r'name="([^"]+)"', headers)
        if not name_m:
            continue
        name = name_m.group(1)
        filename_m = re.search(r'filename="([^"]*)"', headers)
        if filename_m:
            out[name] = {"filename": filename_m.group(1), "content": content}
        else:
            out[name] = {"value": content.decode(errors="replace")}
    return out

def load_package_data(package_dir):
    # Several aggregation datasets now exist (AUC-ROC vs Accuracy, AUC-ROC vs
    # AUCPR, Balanced Accuracy vs F1, MCC vs Balanced Accuracy). The single
    # scatter widget embedded on the local page is wired to the original
    # AUC-ROC vs Accuracy leaderboard, so that one is selected explicitly
    # rather than relying on glob order. The full 5-metric table on the page
    # is built directly from the package's assessment datasets, independent
    # of this chart.
    primary = f"{package_dir}/datasets/aggregation/Dataset_aggregation_PPI-PhysioClassification.json"
    agg_files = glob.glob(f"{package_dir}/datasets/aggregation/*.json")
    agg_path = primary if os.path.exists(primary) else sorted(agg_files)[0]
    agg = json.load(open(agg_path))
    metrics_files = glob.glob(f"{package_dir}/metadata/Metrics/*.json")
    metrics = [json.load(open(f)) for f in metrics_files]
    return agg, metrics

# In-memory only (never written to disk, cleared on server restart): the most
# recently evaluated upload, merged into the chart's data so the EXISTING
# AUC-ROC-vs-Accuracy chart updates in place instead of a second chart being
# created. Replaced (not appended to) on each new submission, matching the
# same "latest submission only" behavior used for the metrics table row.
LIVE_SUBMISSION_POINT = None


def build_dataset_response(agg):
    # The visualizer JSON.parse()'s datalink.inline_data client-side, so it must
    # be sent as a STRING here, not a nested JSON object.
    record = dict(agg)
    inline = dict(agg["datalink"]["inline_data"])
    participants = list(inline.get("challenge_participants", []))
    if LIVE_SUBMISSION_POINT is not None:
        participants = participants + [LIVE_SUBMISSION_POINT]
    inline["challenge_participants"] = participants
    record["datalink"] = {"inline_data": json.dumps(inline)}
    return {"data": {"getDatasets": [record]}}

def evaluate_submission(package_dir, strategy_key, participant_name, csv_text, group_name=None):
    """Evaluates an uploaded predictions CSV under the chosen CV splitting
    strategy, using the SAME leakage-safe procedure (per-fold Youden's J
    threshold learned on the other folds only) already used to precompute
    the baseline leaderboard for the 14 package participants, so the
    comparison is apples-to-apples. Returns {new_result, leaderboard,
    strategy_label, strategy_doc_link, error?}."""
    if strategy_key not in STRATEGY_FILES:
        return {"error": f"unknown strategy '{strategy_key}'"}

    mref_dir = os.path.join(package_dir, "datasets", "metrics_reference")
    gold = cv_evaluate.load_gold_standard(os.path.join(mref_dir, "gold_standard_labels.csv"))
    fold_of = cv_evaluate.load_fold_assignment(os.path.join(mref_dir, STRATEGY_FILES[strategy_key]))

    # parse the uploaded CSV text with the same loader used for the package's
    # own participant files (accepts entry_id + score/raw_score/raw_score_oriented)
    import csv, io as _io
    scores = {}
    reader = csv.DictReader(_io.StringIO(csv_text))
    cols = reader.fieldnames or []
    score_col = None
    for cand in ("raw_score_oriented", "score", "raw_score"):
        if cand in cols:
            score_col = cand
            break
    if "entry_id" not in cols or score_col is None:
        return {"error": (
            "uploaded file must be a CSV with an 'entry_id' column and a score "
            "column named 'raw_score_oriented', 'score', or 'raw_score' (higher "
            "value = more physiological). Columns found: " + ", ".join(cols)
        )}
    for row in reader:
        eid, val = row.get("entry_id"), row.get(score_col)
        if eid and val not in (None, ""):
            try:
                scores[eid] = float(val)
            except ValueError:
                continue

    cv_result = cv_evaluate.cross_validate(scores, gold, fold_of)
    if cv_result.get("n_entries", 0) == 0:
        return {"error": "no uploaded entry_id matched the gold standard / fold assignment -- check the entry_id format (expects e.g. '1a17_6')"}

    leaderboard_path = os.path.join(package_dir, "qc_analysis", "cv_leaderboard", f"{strategy_key}.json")
    baseline = json.load(open(leaderboard_path))
    for row in baseline["participants"]:
        row["submission_file_url"] = f"/package/datasets/participant/{row['participant_id']}/predictions.csv"

    global LIVE_SUBMISSION_POINT
    LIVE_SUBMISSION_POINT = {
        "tool_id": (participant_name or "Uploaded submission")[:22],
        "metric_x": cv_result["cv_auroc_mean"],
        "metric_y": cv_result["cv_accuracy_mean"],
    }

    new_row = {
        "participant_id": "UPLOADED_" + re.sub(r"[^A-Za-z0-9_-]", "_", participant_name or "submission"),
        "display_name": participant_name or "Uploaded submission",
        "group_name": group_name.strip() if group_name and group_name.strip() else "User submission",
        "submission_file_url": None,  # the uploaded file itself is not persisted server-side
        "n_entries": cv_result["n_entries"], "n_folds": cv_result["n_folds"],
        "cv_auroc_mean": cv_result["cv_auroc_mean"], "cv_auroc_std": cv_result["cv_auroc_std"],
        "cv_aucpr_mean": cv_result["cv_aucpr_mean"], "cv_aucpr_std": cv_result["cv_aucpr_std"],
        "cv_balanced_accuracy_mean": cv_result["cv_balanced_accuracy_mean"], "cv_balanced_accuracy_std": cv_result["cv_balanced_accuracy_std"],
        "cv_f1_mean": cv_result["cv_f1_mean"], "cv_f1_std": cv_result["cv_f1_std"],
        "cv_mcc_mean": cv_result["cv_mcc_mean"], "cv_mcc_std": cv_result["cv_mcc_std"],
        "is_new_submission": True,
    }
    combined = list(baseline["participants"]) + [new_row]
    combined.sort(key=lambda r: (r["cv_auroc_mean"] is None, -(r["cv_auroc_mean"] or 0)))
    for i, r in enumerate(combined):
        r["rank"] = i + 1

    return {
        "strategy": strategy_key,
        "strategy_label": baseline["label"],
        "fold_file": baseline["fold_file"],
        "fold_file_url": f"/package/datasets/metrics_reference/{baseline['fold_file']}",
        "reference_data_url": "/package/datasets/metrics_reference/gold_standard_labels.csv",
        "strategy_doc_url": "/CV_SPLITTING_STRATEGIES.md",
        "new_result": new_row,
        "chart_tool_id": LIVE_SUBMISSION_POINT["tool_id"],  # the exact (possibly truncated)
                                                              # label the chart library will use
                                                              # for this point's DOM id, so the
                                                              # client can target it precisely
        "per_fold_detail": cv_result["per_fold"],
        "leaderboard": combined,
    }


def build_metrics_response(metrics):
    out = []
    for m in metrics:
        out.append({
            "_id": m["_id"],
            "title": m.get("title", m["_id"]),
            "_metadata": json.dumps({}),
            "representation_hints": None,
        })
    return {"data": {"getMetrics": out}}

class Handler(BaseHTTPRequestHandler):
    package_dir = None
    static_dir = None

    def _send_json(self, payload):
        body = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        raw_body = self.rfile.read(length)

        if self.path == "/graphql":
            body = json.loads(raw_body or b"{}")
            query = body.get("query", "")
            agg, metrics = load_package_data(self.package_dir)
            if "getMetrics" in query:
                self._send_json(build_metrics_response(metrics))
            else:
                self._send_json(build_dataset_response(agg))
            return

        if self.path == "/api/evaluate_submission":
            content_type = self.headers.get("Content-Type", "")
            try:
                fields = parse_multipart(raw_body, content_type)
                strategy_key = fields.get("strategy", {}).get("value", "strategy3")
                participant_name = fields.get("participant_name", {}).get("value", "").strip()
                group_name = fields.get("group_name", {}).get("value", "").strip()
                file_field = fields.get("predictions_file")
                if not file_field or "content" not in file_field:
                    self._send_json({"error": "no predictions_file uploaded"}); return
                csv_text = file_field["content"].decode("utf-8", errors="replace")
                result = evaluate_submission(self.package_dir, strategy_key, participant_name, csv_text, group_name=group_name)
                self._send_json(result)
            except Exception as e:
                self._send_json({"error": f"server error while evaluating submission: {e}"})
            return

        self.send_response(404); self.end_headers()

    def do_GET(self):
        path = self.path.split("?")[0]

        if path == "/api/strategies":
            labels = {
                "strategy1": "Strategy 1 \u2014 CATH superfamily / UniProt gene (853 groups)",
                "strategy2": "Strategy 2 \u2014 this package's own MMseqs2 clustering (1076 clusters)",
                "strategy2b": "Strategy 2b \u2014 authoritative blastclust reference, -S25 -L0.5 -bF (1045 clusters)",
                "strategy3": "Strategy 3 \u2014 combined union of Strategy 1 + 2b (688 components) \u2014 RECOMMENDED",
            }
            self._send_json({"strategies": [{"key": k, "label": v, "fold_file": STRATEGY_FILES[k]} for k, v in labels.items()]})
            return

        if path == "/CV_SPLITTING_STRATEGIES.md":
            fpath = os.path.join(self.package_dir, "CV_SPLITTING_STRATEGIES.md")
            if os.path.isfile(fpath):
                data = open(fpath, "rb").read()
                self.send_response(200)
                self.send_header("Content-Type", "text/markdown; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            self.send_response(404); self.end_headers(); return

        if path == "/predictions_template.csv":
            body = b"entry_id,score\n1a17_6,0.73\n1a3a_1,0.21\n# score: higher value must mean MORE physiological\n"
            self.send_response(200)
            self.send_header("Content-Type", "text/csv")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Content-Disposition", 'attachment; filename="predictions_template.csv"')
            self.end_headers()
            self.wfile.write(body)
            return

        if path.startswith("/package/"):
            # Serves read-only, downloadable copies of package data files --
            # each participant's own submission file (predictions.csv) and
            # the reference data used for evaluation (gold standard labels,
            # the fold-assignment file for whichever CV strategy is linked).
            rel = path[len("/package/"):]
            base = os.path.abspath(self.package_dir)
            fpath = os.path.abspath(os.path.join(base, rel))
            if not fpath.startswith(base + os.sep) or not os.path.isfile(fpath):
                self.send_response(404); self.end_headers(); return
            data = open(fpath, "rb").read()
            ctype = "text/csv" if fpath.endswith(".csv") else ("text/markdown" if fpath.endswith(".md") else "application/json")
            self.send_response(200)
            self.send_header("Content-Type", ctype + "; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Content-Disposition", f'attachment; filename="{os.path.basename(fpath)}"')
            self.end_headers()
            self.wfile.write(data)
            return

        if path in ("/", "/index.html"):
            # A full page load/reload (browser refresh, re-navigating to the URL) resets the
            # client-side Full metrics table and Quartile table back to their static,
            # server-rendered 14-participant baseline -- they are plain HTML, not re-fetched via
            # AJAX, so a previous submission's row simply isn't there anymore after a refresh.
            # The chart, however, is rebuilt from a live GraphQL fetch every time
            # load_scatter_visualization() runs (including on this fresh page load), and would
            # otherwise keep showing a stale point from a submission the rest of the page no
            # longer reflects, since LIVE_SUBMISSION_POINT is server-side state with no notion of
            # "this request is a reload" to key off. Clearing it here keeps the chart consistent
            # with the table on every full page (re)load, while still updating live within a
            # single page session via the submit form as before.
            global LIVE_SUBMISSION_POINT
            LIVE_SUBMISSION_POINT = None

        if path == "/":
            path = "/index.html"
        fpath = os.path.join(self.static_dir, path.lstrip("/"))
        if not os.path.isfile(fpath):
            self.send_response(404); self.end_headers(); return
        ctype = "text/html"
        if fpath.endswith(".js"): ctype = "application/javascript"
        elif fpath.endswith(".css"): ctype = "text/css"
        elif fpath.endswith(".png"): ctype = "image/png"
        with open(fpath, "rb") as fh:
            data = fh.read()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):
        pass  # quiet

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--package", default=None)
    ap.add_argument("--static", default=None)
    args = ap.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    if args.package is None:
        args.package = resolve_default_package_dir()
    if args.static is None:
        args.static = os.path.join(here, "visualizer_static")

    Handler.package_dir = args.package
    Handler.static_dir = args.static
    server = HTTPServer(("127.0.0.1", args.port), Handler)
    print(f"Serving local OpenEBench visualizer at http://localhost:{args.port}/")
    print(f"  data source: {args.package}")
    server.serve_forever()

if __name__ == "__main__":
    main()
